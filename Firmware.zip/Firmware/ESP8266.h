#ifndef _ESP8266_SOFTWARE_SERIAL_H_
#define _ESP8266_SOFTWARE_SERIAL_H_

#define ESP8266_USE_SOFTWARE_SERIAL
#include "ESP8266_common.h"

#endif